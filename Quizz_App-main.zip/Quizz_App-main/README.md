# Quizz_App

• Aims of this project is to develop an android platform supported 
Quiz application named “Android Quiz Application”.
• The main effect of this application is that anyone and anywhere quiz 
can be given.
• Provide security for all data about user store on their personal 
account. 
• It also stores the data about the quizzes which have solved by user. 
• Different types of quiz are added with engineering branch for every 
student. 
• The student can select the quiz mode in types such as practice mode, 
exam mode, interview mode. 
• We will provide the interview frequently asked question in different
companies. 
• This application will be easily controlled by users and will be 
friendly for users.
